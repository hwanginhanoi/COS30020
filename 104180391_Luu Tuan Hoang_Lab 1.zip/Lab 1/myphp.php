<!DOCTYPE html>
<html lang="en">
    <head>
        <title>My First PHP webpage</title>
        <meta charset="utf-8">
        <meta name="description" content="Web development">
        <meta name="keywords" content="HTML, CSS, JavaScript">
        <meta name="author" content="your name">
    </head>
    <body>
        <h1>Web Programming - Lab 1</h1>
        <p>Can I create a .php file that do not contain any PHP scripts?</p>
        <p>Yes, but this should be avoided, so that the server does not do any
            unnecessary parsing and processing.</p>
    </body>
</html>