<?php
    $host = "feenix-mariadb.swin.edu.au";
    $user = "s104180391";
    $pswd = "310104";
    $dbnm = "s104180391_db";
?>