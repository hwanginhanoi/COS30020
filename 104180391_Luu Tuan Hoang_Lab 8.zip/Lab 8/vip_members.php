<!doctype html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport"
              content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Document</title>
    </head>
    <body>
        <body>
            <h1>Home Page</h1>
            <p><a href="member_add_form.php">Add New Member Form</a></p>
            <p><a href="member_display.php">Display All Members Page</a></p>
            <p><a href="member_search.php">Search Member Page</a></p>
        </body>
    </body>
</html>