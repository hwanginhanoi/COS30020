<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="description" content="Web application development" />
        <meta name="keywords" content="PHP" />
        <meta name="author" content="Your Name" />
        <title>TITLE</title>
    </head>
    <body>
        <h1>Lab04 Task 3 - Standard Palindrome</h1>
        <form action ="standardpalindrome.php" method ="post" >
            <label for="var">String</label>
            <input type="text" id="var" name="var">
            <button type="submit">Check for Standard Palindrome</button>
        </form>
    </body>
</html>