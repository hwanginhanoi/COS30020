<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8"/>
        <meta name="description" content="Web Application Development :: Lab 3"/>
        <meta name="keywords" content="Web,programming"/>
        <title>Using if and while statements</title>
    </head>
    <body>
        <h1>Web Application Development - Lab 3</h1>
        <form action="leapyear.php" method="get">
            <label for="var">Year</label>
            <input type="number" id="var" name="var" required>
            <button type="submit">Submit</button>
        </form>
    </body>
</html>