<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <meta name="description" content="Web Programming :: Lab 2" />
        <meta name="keywords" content="Web,programming" />
        <title>Using variables, arrays and operators</title>
    </head>
    <body>
        <form action="iseven.php" method="get">
            <label for="var">Input data</label>
            <input type="text" id="var" name="var" required>
            <button type="submit">Submit</button>
        </form>
    </body>
</html>