<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="description" content="Web application development" />
        <meta name="keywords" content="PHP" />
        <meta name="author" content="Luu Tuan Hoang" />
        <title>TITLE</title>
    </head>
    <body>
        <h1>Lab06 Task 2 - Guestbook</h1>
        <form action="guestbooksave.php" method="post">
            <fieldset>
                <legend><b>Enter your details to sign our guest book</b></legend>
                <p>First Name
                    <input name="name"/>
                </p>
                <p>Email
                    <input name="email"/>
                </p>
                <input type="submit" value="Submit"/>
                <input type="reset">
            </fieldset>
        </form>
        <br>
        <a href="guestbookshow.php">View Guest Book</a>
    </body>
</html>

<style>

</style>